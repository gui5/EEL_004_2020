clear;
clc;
t = 0:0.000001:0.002;
y = 2*cos((2*pi*1500*t) + (pi/2));
plot(t,y);
