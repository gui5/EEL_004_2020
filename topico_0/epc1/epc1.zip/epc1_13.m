function bin = epc1_13(n)
  bin = dec2bin(hex2dec(n));
endfunction
