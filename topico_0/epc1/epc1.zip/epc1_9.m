clc;
clear;

c = input("Insira um numero complexo: ");

x = conj(c);

disp("Conjugado de "), disp(c), disp("="), disp(x)



