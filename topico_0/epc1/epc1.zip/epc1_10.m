clc
clear

n = input("Entre com um numero: ")
dec2bin(round(real(n)))
